//
//  main.swift
//  Sudoku
//
//  Created by Hamza Crichlow on 11/12/24.
//

import Foundation



var rowExample = [
    [1,2,0,4,5,6,0,8,9]
]
var columnExample = [
    [4],
    [7],
    [0],
    [1],
    [3],
    [0],
    [2],
    [8],
    [9],
    
]
var threeXThreeExample = [
    [9,1,3],
    [6,5,0],
    [2,8,4],
]
func printRules() {
    print("--------------------------------")
    print("-----  HOW TO PLAY SUDOKU  -----")
    print("--------------------------------")
    print("")
    print("You will be presented a grid of numbers. Some of those numbers will be missing signified by an underscore (_).")
    print("Your job is to fill all the missing numbers WITHOUT REPEATING the same number in a row, column, or 3x3 box.")
    print("")
    print("The grid works like this : ")
    print("--------------------------------")
    print("Every Row has a non-repeating number 1 - 9 : ")
    for row in rowExample {
        for numbers in row {
            if numbers == 0 {
                print ("_", terminator: " ")
            } else {
                print(numbers, terminator: " ")
            }
        }
        
    }
    print("")
    print("Notice that there are missing numbers in this row. What are the missing numbers? They are 3 and 7.")
    print("")
    print("Every Column has a non-repeating number 1 - 9 : ")
    for column in columnExample {
        for numbers in column {
            if numbers == 0 {
                print ("_", terminator: " ")
            } else {
                print(numbers, terminator: " ")
            }
        }
        print("")
    }
    print("Notice that there are missing numbers again? This time its a little tricky because they are out of order. Regardless, there can be NO REPEATS of numbers. So what are the missing numbers this time? They are 5 and 6.")
    print("")
    print("The grid you will be filling in is made up of nine 3 X 3 boxes. Every 3x3 box also has a non-repeating number 1 - 9 : ")
    for row in threeXThreeExample {
        for numbers in row {
            if numbers == 0 {
                print ("_", terminator: " ")
            } else {
                print(numbers, terminator: " ")
            }
        }
        print("")
    }
    print("Notice that there is a missing number again? So what is the missing number this time? It is 7.")
    print("")
    print("")
    print("You cannot repeat numbers 1-9 in a row, column, or a 3x3 box")
    print("--------------------------------")
    print("Do not be intimidated. Sudoku is easy. This is how a full Sudoku Board will look :")
    print("")
    printGrid(easyGrid)
    print("")
    print("How do you add missing numbers to fill the grid? :")
    print("The left line of numbers with the \"R\" above them represents the different rows index. First you will choose what row you want to input the number.")
    print("The top row of numbers with \"Column\" above represents each column from 0 - 8. Second you will choose which column you'd like to enter the number.")
    print("Third you will enter whatever number you think goes in the missing spot.")
    print("You will continue to fill in all the missing spots until you WIN!")
    print("")
    print("Dont worry youll do fine.")
    print("Good luck and have fun!")
    print("--------------------------------")
    print("")
    print("")
    print("")
}

//This is the RestartGame() function that is called when the game is over so the player can choose if they want to play again or not. It is a switch case.
// If the player chooses yes we call the ChooseLevel() function. This function takes the player through another switch case of "easy", "medium", or "hard" options. If they choose no then we print "Okay, thanks for playing." adn the game ends.
func restartGame(){
    
    print("Do you want to play again?")
    
    if let input: String = readLine()?.lowercased(){
    switch input {
        case "yes":
        chooseALevel()
        case "no":
        print("Okay, thanks for playing.")
       
        default:
        print("Lets try that again. Please type in \"yes\" or \"no\" without any spaces.")
        restartGame()
            }
}
}


//This checkInput() function pretty much is taking whatever number they input and figures out if that number matches the same number as the answer key then if it is correct then the function will return true. If they put the wrong number then it will return false and print " Incorrect ): Sorry ".
//answerKey[row][column] : The first []'s are filled with row. Like this : answerkey[row]. Thats telling the function to go through the answerKey array and choose whichever index we insert which will be called by inserting the row number 0-8. The word "row" is a placeholder name for the arrays within the answerKey array. So now we have answerKey[row][]. The second []'s are filled with column. This is kind of misleading becuase column is really just a placeholder name for the index in the "row" array. Each index in the answerKey[row][column] corresponds with one of the numbers on the answerKey grid. And if that number in the answer key is equal to the number the player inserted then the function checkInput() will return true and print " (: Good Job! (: ".
    func checkInput(grid: [[Int]], answerKey: [[Int]],row: Int, column: Int, number: Int) -> Bool {
      
        if answerKey[row][column] == number {
            print(" (: Good Job! (: ")
            return true
        }
        
        else{
            print(" Incorrect ): Sorry ")
            return false
        }
    }
    
    
//The makeMove() function is for how the player will make a move. This function is called within the playSudoku() function. The player has to input the column the row and the number of their choosing.
//Choose a Row
//Choose a Column
//Choose a Number 1-9 to insert it into the missing place on the grid
//Int(readLine()!)!  The ! is used to force unwrap optionals. The readLine() function returns an optional string (String?). The readLine() function reads a line of text from the players input. THis means that it may hold a value or it may be nil. When we say readLine()! We are telling the code that readLine() needs to be unwrapped which pretty much means that we know for a fact that there is a value and its not nil. Because that is unwrapped we also need to unwrap the Int part by adding another !
//After the player puts their input we call the checkInput() function. This function is a bool and will always return true or false. So if its true we go to whats beneath it. Which is "grid[row][column] = number" this is how we update the grid to have the players input on it. If the function returns false it prints "Wrong Move".
func makeMove(grid: inout [[Int]], answerKey: [[Int]]) {
    
        print("Enter Row (0-8): ", terminator: "")
        let row = Int(readLine()!)!
        print("Enter Column (0-8): ", terminator: "")
        let column = Int(readLine()!)!
        print("Enter a number (1-9): ", terminator: "")
        let number = Int(readLine()!)!
      
        if checkInput(grid: grid, answerKey: answerKey, row: row, column: column, number: number) {
            grid[row][column] = number
        } else {
            print ("Wrong Move")
        }
    
    }


//These are all the grids we have with there answer keys :
var easyGridAnswers = [
[4,3,5,2,6,9,7,8,1],
[6,8,2,5,7,1,4,9,3],
[1,9,7,8,3,4,5,6,2],
[8,2,6,1,9,5,3,4,7],
[3,7,4,6,8,2,9,1,5],
[9,5,1,7,4,3,6,2,8],
[5,1,9,3,2,6,8,7,4],
[2,4,8,9,5,7,1,3,6],
[7,6,3,4,1,8,2,5,9],
]
var easyGrid = [
[4,3,0,2,6,9,7,8,1],
[6,8,2,5,7,1,4,9,3],
[1,9,7,8,3,4,5,0,2],
[8,2,6,1,9,5,3,4,7],
[3,0,4,6,8,2,9,1,5],
[9,5,1,7,4,3,6,2,8],
[5,1,9,3,2,0,8,7,4],
[2,4,8,9,5,7,1,3,6],
[7,6,3,4,1,8,2,0,9],
]

var mediumGridAnswers = [
[1,2,3,6,7,8,9,4,5],
[5,8,4,2,3,9,7,6,1],
[9,6,7,1,4,5,3,2,8],
[3,7,2,4,6,1,5,8,9],
[6,9,1,5,8,3,2,7,4],
[4,5,8,7,9,2,6,1,3],
[8,3,6,9,2,4,1,5,7],
[2,1,9,8,5,7,4,3,6],
[7,4,5,3,1,6,8,9,2],
]

var mediumGrid = [
[1,2,0,6,0,8,0,0,0],
[5,8,0,0,0,9,7,0,0],
[0,0,0,0,4,0,0,0,0],
[3,7,0,0,0,0,5,0,0],
[6,0,0,0,0,0,0,0,4],
[0,0,8,0,0,0,0,1,3],
[0,0,0,0,2,0,0,0,0],
[0,0,9,8,0,0,0,3,6],
[0,0,0,3,0,6,0,9,0],
]

var hardGridAnswers = [
[5,8,1,6,7,2,4,3,9],
[7,9,2,8,4,3,6,5,1],
[3,6,4,5,9,1,7,8,2],
[4,3,8,9,5,7,2,1,6],
[2,5,6,1,8,4,9,7,3],
[1,7,9,3,2,6,8,4,5],
[8,4,5,2,1,9,3,6,7],
[9,1,3,7,6,8,5,2,4],
[6,2,7,4,3,5,1,9,8],
]

var hardGrid = [
[0,0,0,6,0,0,4,0,0],
[7,0,0,0,0,3,6,0,0],
[0,0,0,0,9,1,0,8,0],
[0,0,0,0,0,0,0,0,0],
[0,5,0,1,8,0,0,0,3],
[0,0,0,3,0,6,0,4,5],
[0,4,0,2,0,0,0,6,0],
[9,0,3,0,0,0,0,0,0],
[0,2,0,0,0,0,1,0,0],
]





//This is the printGrid() function. It will print whatever grid array is inserted thorught its parameter.
//The Column string at the top is just a label so the player can easily see what column to choose when playing.
//for (index, row) in array.enumerated() : index calls the the index from 0-8 because we have 9 different arrays. It starts at 0 then goes up to 8. So (index, row) calls for the index of the array. To loop through the array and figure out the index of each rows position we use "array.enumerated()" so we can print it in front of each row so the player can choose a a row more easily. Next we print ("\index") with a line after it "|" so we can label our rows.
// The word "row" is placeholder name for every array within the grids array.
// The word "number" is a placeholder name for every number within the row array.
// We want the board to show an underscore for missing numbers so thats why we say if the number is equal to 0 print "_" anything else then just print whatever number is actually there.
//Terminator allows the next line of code to come and continue on the same line instead of go to the next line.
func printGrid(_ array: [[Int]]) {
    
        print("    Column ")
        print("R   0 1 2 3 4 5 6 7 8")
        print("-----------------")
      
    for (index, row) in array.enumerated() {
        print("\(index) |", terminator: " ")
            for number in row {
                if number == 0 {
                    print ("_", terminator: " ")
                } else {
                    print(number, terminator: " ")
                }
            }
            print (" ")
        }
    }

//Here we have the playSudoku() function. Parameters that ae passed through a function are usually constants. Meaning you cant change them. If you pass in a paramter with inout then it can be changed inside the function. We need this "inout" because we will be changing or mutating the grid we insert based on what the player adds to the grid.
//We have to remember to use the "&" symbol while inside the function to explicityly recognize that the "inout" is being used.
//In our function the first thing we did was establish a variable "gameOn" This variable signifies the game is being played. It is a Bool set to true. As long as its true the game will play. Once its set to false (!gameOn) the game is over.
//We start the game by printing whatever grid was put into our function parameter.
//Then we allow the player to make a move by calling the makeMove() function. Notice the "&" in front of the grid to let us know that it is going to mutate based on what the player adds to the grid.
//gameOn = grid.flatMap {$0}.contains(0) Here we are establishing that while the game is on there has to be zeros on the grid. We made the zeroes show up as underscores in the printGrid() function above. The .flatMap pretty much converts multidimensional arrays (like the ones we have for our grids) into single dimensional arrays. So after doing that we add the .contains(0) to add that rule and say while there are still zeroes the game is on. Therefore when the player removes all the zeroes by filling in all the empty underscore spots the game is over (!gameOn) and we print Congratulations and call the RestartGame() function.
func playSudoku(grid: inout [[Int]], answerKey: [[Int]]) {
        
    var gameOn = true
    
    while gameOn {
            printGrid(grid)
            makeMove(grid: &grid, answerKey: answerKey)
        
            gameOn = grid.flatMap {$0}.contains(0)
        
            if !gameOn {
                print ("Congratulations! You win!")
               
                restartGame()
            }
        }
    }
    
//Here we call the ChooseALevel() function. This goes through a switch case allowing the player to choose if they want to play an "easy", "medium", or "hard" level. If the player types in anything else it switches to the default case which tells the player that they made a mistake and lets them know to only enter "easy" "medium" or "hard" with no capital letters or spaces.
//Based on whatever level the player chooses that case will call the playSudoku() function and will input the corresponding parameters into the function which are : the "grid" that the player will be filling out, and the "answerKey" to compare the players inputs too.
// The reason we have "&" in front of the grid in the playSudoku() function is because we need to let the function know that the grid we choose will eventually mutate because our player will be inputing numbers into the empty spots on the grid.The answerKey grids dont need the "&" because they will never mutate. They will stay as they are and we will use them to compare the players input too.
func chooseALevel() {
    print("------------------")
    print("Would you like to play an \"easy\", \"medium\", or \"hard\" grid?")
    if let level: String = readLine()?.lowercased() {
        switch level{
        case "easy":
            playSudoku(grid: &easyGrid, answerKey: easyGridAnswers )
        case "medium":
            playSudoku(grid: &mediumGrid, answerKey: mediumGridAnswers)
        case "hard":
            playSudoku(grid: &hardGrid, answerKey: hardGridAnswers)
        default:
            print("Uh-Oh !? I think you made a mistake. Please type in \"easy\", \"medium\", or \"hard\" without any spaces.")
            chooseALevel()
        }
    }
}

//Here we give the player a yes or no question by calling the yesOrNo() function. If the player enters anything other than "yes" or "no" then it switches to the default case which prints and tells the player that they must have entered an incorrect option and lets them know to try again and and make sure that there are no spaces or capital letters. Then it recycles through the same function until they give a correct answer: "yes" or "no"
// If the player chooses yes we call the printRules() function. All that does is print the rules that we have written way above.
//After printing the rules we call the ChooseALevel() function. This function takes the player through another switch case of "easy", "medium", or "hard" options.
// If the player chooses no we do not print the rules we jump right into the ChooseLevel() function.
func yesOrNo() {
    if let input: String = readLine()?.lowercased(){
        
        switch input {
        case "yes":
            printRules()
            chooseALevel()
        case "no":
            chooseALevel()
        default:
            print("Lets try that again. Please type in \"yes\" or \"no\" without any spaces.")
            yesOrNo()
        }
    }
}

//This is where the game begins. We have a welcome letter and then a yes or no question in the yesOrNo()function that will initialize the game.
// The yesorNo() function takes the player through a switch case yes or no.
//print("Welcome to Sudoku!")
print("------------------")
print("Do you need to learn how to play?")
print("Please enter \"yes\" or \"no\"")

yesOrNo()





